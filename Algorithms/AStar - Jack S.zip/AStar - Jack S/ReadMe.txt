                       ___         _            ___       __        _______   ______   .______       __  .___________. __    __  .___  ___.                   
 ______ ______        /   \     /\| |/\        /   \     |  |      /  _____| /  __  \  |   _  \     |  | |           ||  |  |  | |   \/   |     ______ ______ 
|______|______|      /  ^  \    \ ` ' /       /  ^  \    |  |     |  |  __  |  |  |  | |  |_)  |    |  | `---|  |----`|  |__|  | |  \  /  |    |______|______|
 ______ ______      /  /_\  \  |_     _|     /  /_\  \   |  |     |  | |_ | |  |  |  | |      /     |  |     |  |     |   __   | |  |\/|  |     ______ ______ 
|______|______|    /  _____  \  / , . \     /  _____  \  |  `----.|  |__| | |  `--'  | |  |\  \----.|  |     |  |     |  |  |  | |  |  |  |    |______|______|
                  /__/     \__\ \/|_|\/    /__/     \__\ |_______| \______|  \______/  | _| `._____||__|     |__|     |__|  |__| |__|  |__|                   
                                                                                                                                                              

Instructions - When the program loads, select a premade map, or select 'blank map' for a blank canvas
             - Once the map has loaded, use the left mouse button to draw, and the right to erase (double click RMB to clear canvas)
             - Once you are done with drawing, press the enter key
             - Click where you want the path to begin, followed by where you want it to end
             - ???
             - Path

Orange nodes are nodes that have been expanded by the algorithm and moved to the closed list
Yellow nodes represent child nodes that have not yet been expanded, and are still in the open list
Green nodes represent the path